Date: Mon Dec  1 20:29:36 CST 2025

Node: v22.21.1
NPM: 10.9.4

Env hints (no secrets):
- expects POLYGON_API_KEY, FRED_API_KEY
- app dir: app/
- charts in components/TVGrid.tsx etc.

